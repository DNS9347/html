let currentInput = '';
let resultDisplayed = false;
let isNegative = false;

function addToInput(value) {
    if (resultDisplayed) {
        clearDisplay();
    }
    if (value === '+/-') {
        isNegative = true;
        updateDisplay();
        return;
    }
    if (isNegative) {
        if (!isNaN(value) || value === '.') {
            currentInput += '-' + value;
        } else {
            currentInput += value;
        }
        isNegative = false;
    } else {
        currentInput += value;
    }
    updateDisplay();
}

function calculate() {
    try {
        const result = eval(currentInput.replace(/%/g, '/100'));
        const formattedResult = Number.isInteger(result) ? result : result.toFixed(2);
        document.getElementById('txt').value = formattedResult;
        currentInput = formattedResult.toString();
        resultDisplayed = true;
    } catch (error) {
        document.getElementById('txt').value = 'Error';
    }
    updateDisplay(); // Update the display with the evaluated expression
}


function clearDisplay() {
    document.getElementById('txt').value = '';
    currentInput = '';
    resultDisplayed = false;
    isNegative = false;
}

function deleteLast() {
    if (resultDisplayed) {
        clearDisplay();
    } else {
        const lastChar = currentInput.slice(-1);
        if (!isNaN(lastChar) || lastChar === '.' || lastChar === '%') {
            currentInput = currentInput.slice(0, -1);
        } else {
            currentInput = currentInput.slice(0, -2);
        }
        updateDisplay();
    }
}

function updateDisplay() {
    const displayValue = isNegative ? '-' + currentInput : currentInput;
    document.getElementById('txt').value = displayValue;
}

// Event listener for keyboard input
// Your existing code...

// Event listener for keyboard input
document.getElementById('txt').addEventListener('keydown', function(event) {
    const key = event.key;
    if (!isNaN(key) || key === '.' || key === '%' || key === '+' || key === '-' || key === '*' || key === '/') {
        addToInput(key);
    } else if (key === 'Enter') {
        calculate();
        event.preventDefault(); // Prevent default behavior of Enter key
    } else if (key === 'Backspace') {
        deleteLast();
    }
});

// Your existing functions (addToInput, calculate, clearDisplay, deleteLast, updateDisplay)
